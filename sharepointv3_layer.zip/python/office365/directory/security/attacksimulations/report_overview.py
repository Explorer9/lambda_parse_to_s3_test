from office365.runtime.client_value import ClientValue


class SimulationReportOverview(ClientValue):
    """Represents an overview report of an attack simulation and training campaign."""
