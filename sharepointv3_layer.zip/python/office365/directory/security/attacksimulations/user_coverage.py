from office365.runtime.client_value import ClientValue


class AttackSimulationSimulationUserCoverage(ClientValue):
    """Represents cumulative simulation data and results for a user in attack simulation and training."""

    def __init__(self):
        pass
