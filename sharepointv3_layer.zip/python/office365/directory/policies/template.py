from office365.entity import Entity


class PolicyTemplate(Entity):
    """Represents the base policy in the directory for multitenant organization settings."""
