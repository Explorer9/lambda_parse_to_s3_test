from office365.runtime.client_request import ClientRequest


class CsomRequest(ClientRequest):
    """"""

    def process_response(self, response, query):
        pass

    def build_request(self, query):
        pass
