class ODataParameter(object):
    def __init__(self, name=None, type_full_name=None):
        self.Name = name
        self.ParameterTypeFullName = type_full_name
