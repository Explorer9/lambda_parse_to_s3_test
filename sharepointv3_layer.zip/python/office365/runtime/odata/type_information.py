class TypeInformation(object):
    def __init__(self):
        self.BaseTypeFullName = None
        self.FullName = None
        self.IsValueObject = None
        self.Methods = []
        self.Properties = []
