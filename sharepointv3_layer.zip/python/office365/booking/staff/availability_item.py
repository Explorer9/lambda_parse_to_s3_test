from office365.runtime.client_value import ClientValue


class StaffAvailabilityItem(ClientValue):
    """Represents the available and busy time slots of a Microsoft Bookings staff member."""
