from office365.runtime.client_value import ClientValue


class SiteArchivalDetails(ClientValue):
    """Represents the archival details of a siteCollection."""
