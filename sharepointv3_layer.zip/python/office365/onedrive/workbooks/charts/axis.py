from office365.entity import Entity


class WorkbookChartAxis(Entity):
    """Represents a single axis in a chart."""
