from office365.entity import Entity


class WorkbookChartTitleFormat(Entity):
    """Represents a chart title object of a chart."""
