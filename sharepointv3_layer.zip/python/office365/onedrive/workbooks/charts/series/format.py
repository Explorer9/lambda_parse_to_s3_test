from office365.entity import Entity


class WorkbookChartSeriesFormat(Entity):
    """Encapsulates the format properties for the chart series"""
