from office365.entity import Entity


class WorkbookChartLegendFormat(Entity):
    """Encapsulates the format properties of a chart legend."""
