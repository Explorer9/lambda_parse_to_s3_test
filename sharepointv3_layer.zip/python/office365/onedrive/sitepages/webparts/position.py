from office365.runtime.client_value import ClientValue


class WebPartPosition(ClientValue):
    """Represents the position information of the given web part to the current page"""
