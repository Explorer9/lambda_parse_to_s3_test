from office365.onedrive.base_item import BaseItem


class FieldValueSet(BaseItem):
    """Represents the column values in a listItem resource."""
