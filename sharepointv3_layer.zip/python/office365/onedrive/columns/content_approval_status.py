from office365.runtime.client_value import ClientValue


class ContentApprovalStatusColumn(ClientValue):
    """Represents a content approval status column in SharePoint."""
