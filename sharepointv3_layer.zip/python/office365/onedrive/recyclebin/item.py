from office365.onedrive.base_item import BaseItem


class RecycleBinItem(BaseItem):
    """Represents information about a deleted item in a recycleBin of a SharePoint site or a SharePoint
    Embedded fileStorageContainer."""
