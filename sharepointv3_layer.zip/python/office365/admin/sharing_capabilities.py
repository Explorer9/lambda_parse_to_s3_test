class SharingCapabilities:
    """"""
