from office365.entity import Entity


class AdminMicrosoft365Apps(Entity):
    """Represents an entity that acts as a container for administrator functionality for Microsoft 365 applications."""
