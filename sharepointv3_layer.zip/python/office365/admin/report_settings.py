from office365.entity import Entity


class AdminReportSettings(Entity):
    """Represents the tenant-level settings for Microsoft 365 reports."""
